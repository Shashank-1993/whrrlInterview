In progress...

appAPI - This folder contains the Node APIs and UI template
    index.js - 1. Contains code to connect to the network with which metamask is connected.
                2. Contains API defination to connect to smart contract functions.

    ui.html - Contains buttons to display all tokens and transfer token.

contracts - This foldeer contains the Token interfaces along with therse implementation smartcontract.

migrations - This folder contains scripts to deploy smart contract on ethereum network.

truffle-config.js - It contains the rinkeBy network configuration where the contract is deployed.

                
 