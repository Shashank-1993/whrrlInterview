const gameContract = artifacts.require("GameItems");

module.exports = function (deployer) {
  deployer.deploy(gameContract);
};