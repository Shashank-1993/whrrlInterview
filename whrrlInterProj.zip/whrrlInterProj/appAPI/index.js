const Web3 = require('web3');
const express = require('express');
const app = express();
const port = 4040

app.get('/',(req,res) => {

    if (window.ethereum != null) {
        state.web3 = new Web3(window.ethereum)
        try {
          // Request account access if needed
           await window.ethereum.enable()
          // Acccounts now exposed
        } catch (error) {
          // User denied account access...
        }
      }
      else{
          console.log("HD wallet instance not found");
      }

    // const web3 = new Web3('https://rinkeby.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161');
    res.sendFile(__dirname + '/ui.html')});


function makeConnection(){
    let contract = web3.eth.contract("Abi of smartContract");
    let contractInstance = contract.at('address where Smartcontract is deployed');

    return contractInstance;
}

app.post('/transferToken', (req,res) => {
    let instance = makeConnection();
    instance.TransferToken(req.Receiver,{from : ,value :},(err,response) => {
        if(err){
            console.log(err);
        }
        else{
            console.log(response);
            res.send(response);
        }
    })
})

app.listen(port, function(err){
        if(err) console.log(err)
        console.log(`Server listening on Port ${port}`);
});